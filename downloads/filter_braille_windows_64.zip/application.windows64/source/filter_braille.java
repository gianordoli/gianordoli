import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.pdf.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class filter_braille extends PApplet {

    // PDF

java.io.File selectedFile;  // File system
String destinationFolderPDF;
boolean isRecordingPDF = false;
String destinationFolderPNG;
boolean isSavingPNG = false;

// Image
PImage myImage;
PVector imagePos;
boolean imageLoaded = false;
boolean showImage = false;

// Message
String msg;
String tip;
PFont myFont;

// About
roundButton btAbout;

// Buttons
int bgColor;
int btColorBackground;
int btColorForeground;
int btColorActive;

// Icon
PGraphics icon;

// Braille
float cellWidth;
float cellHeight;
float dotDiameter;
boolean fixedSize;


public void setup(){
  
    
  
  // Creating Windows Icon
  icon = createGraphics(16, 16, JAVA2D);
  PImage imageIcon = loadImage("icon_16x16.gif");
  icon.beginDraw();
  icon.background(255);
  icon.image(imageIcon, 0, 0);
  icon.endDraw();
  frame.setIconImage(icon.image);
  frame.setTitle("Filter: Braille");   
  
  // Message
  myFont = createFont("Helvetica", 21);
  msg = "Please select an image to start.";
  tip = "Tip: High contrast, black and white images work better. \n Up to 800 x 800 pixels, jpg, png, or gif.";
  
  // About
  btAbout = new roundButton();    
  
  // GUI
  setGUI();  
  
  // Braille cells setup: 3.5 X 5
  cellWidth = 42;
  cellHeight = cellWidth * 1.43f;
  dotDiameter = cellWidth/3.5f;
  fixedSize = true;
  showImage = false;
}

public void draw(){
  
  if(destinationFolderPDF != null) {
    println("Recording PDF");
    isRecordingPDF = true;
    String fileName = destinationFolderPDF + "/braille.pdf";
    println(fileName); 
    beginRecord(PDF, fileName); 
  }else if(destinationFolderPNG != null){
    println("Saving PNG");
    isSavingPNG = true;
  }
    
  background(0);  
  
  // Start Application
  if(imageLoaded){
    
    pushMatrix();
      translate(imagePos.x, imagePos.y);
      
      // Toggle Image Visibility
      if(showImage){
        image(myImage, 0, 0);  
      }
  
      // Draw Cells
      cellHeight = cellWidth * 1.43f;
      dotDiameter = cellWidth/3.5f;
      
      for(float imgX = 0; imgX <= myImage.width - cellWidth; imgX += cellWidth){
       for(float imgY = 0; imgY <= myImage.height - cellHeight; imgY += cellHeight){
         brailleCell(imgX, imgY);
       }  
      }
      
    popMatrix();
    
  // Message  
  }else{
    fill(color(255, 48, 97, 60));
    noStroke();
    rect(0, 0, width, height);
    fill(255);
    textFont(myFont);
    textSize(21);
    textAlign(CENTER, BOTTOM);
    text(msg, width/2, height/2);
    textSize(13);
    textLeading(21);
    textAlign(CENTER, TOP);
    text(tip, width/2, height/2 + 10);    
  }
  
  if(isRecordingPDF){
    endRecord();
    destinationFolderPDF = null;
    isRecordingPDF = false;
    imageLoaded = false;
    println("Finished recording.");
  }
  
  if(isSavingPNG){
    save(destinationFolderPNG + "/braille.png");
    destinationFolderPNG = null;
    isSavingPNG = false;
    imageLoaded = false;
    println("Finished saving.");
  }
  
  btAbout.display();
}

public void brailleCell(float _imgX, float _imgY){
  fill(255);
  noStroke();
  for(float x = _imgX; x <= _imgX + dotDiameter * 2.5f; x += 1.5f * dotDiameter){
    for(float y = _imgY; y <= _imgY + dotDiameter * 4; y += 1.5f * dotDiameter){
      //println("x: " + x + " | y: " + y);
      
      float diameter = 0;
      
      if(fixedSize){
        // A)
        float b = brightness(getColorAt(floor(x), floor(y))); 
        if(50 < b && b < 150){
          diameter = dotDiameter*0.5f;
        }else if(b >= 150){
          diameter = dotDiameter;
        } 
        
      }else{
        // B)
        diameter = map(brightness(getColorAt(floor(x), floor(y))),
                            0, 255,
                            0, dotDiameter);      
      }
      
      ellipse(x, y, diameter, diameter);
    }
  }
  
}

public int getColorAt(int _x, int _y){
  int i = _y * myImage.width + _x;
  int c = myImage.pixels[i];
  return c;  
}


public void mouseReleased(){
  if(imageLoaded == false && myImage != null){
    imageLoaded = true;
  }
  if(btAbout.isHovering()){
    link("http://gianordoli.com/projects.html#nAOAh0kazd");
  }  
}
//GUI

ControlP5 cp5;
Accordion accordion;

int cWidth = 150;
int cHeight = 20;
int cPadding = 10;
int cX = cPadding;
int cY = cPadding;

public void setGUI(){
  
  cp5 = new ControlP5(this);
  
  bgColor = color(255, 48, 97, 100);
  btColorBackground = color(255, 48, 97, 160);
  btColorForeground = color(255, 48, 97, 230);
  btColorActive = color(255, 48, 97, 255);
  
  //Toggle visibility 
  cp5.mapKeyFor(new ControlKey() {
    public void keyEvent() {
      if(accordion.isVisible()){
        accordion.setVisible(false);  
      }else{
        accordion.setVisible(true);
      }
    }
  }, '0');
  
  accordion = cp5.addAccordion("acc")
                 .setPosition(10, 10)
                 .setWidth(cWidth + 2* cPadding)                
                 ;                 
                 
  setAddFileGroup();
}

public void setAddFileGroup(){
  Group g0 = cp5.addGroup("input")
                .setWidth(cWidth + 2 * cPadding)
                .setBackgroundColor(bgColor)
                .setColorBackground(btColorBackground)
                .setColorForeground(btColorForeground)
                .setColorActive(btColorActive)                 
                ;

  cp5.addButton("select")
   .setPosition(cX, cY)
   .setColorBackground(btColorBackground)
   .setColorForeground(btColorForeground)
   .setColorActive(btColorActive)
   .setCaptionLabel("Select Image")
   .setGroup(g0)   
   ;
   
  accordion.addItem(g0)
           .setItemHeight(cHeight + 2 * cPadding)
           ;
           
  accordion.open(0)
           .setCollapseMode(Accordion.MULTI)
           ;           
}

public void select() {
 
  println("Called select"); 
  
  selectInput("Select an image file:", "fileSelected");
}

public void fileSelected(File selection) {
  
  println("Called fileSelected");
  
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    String path = selection.getAbsolutePath();
    println("User selected " + path);
    createImage(path);
  }
}

public void createImage(String path){
  
  println("Called createImage");
  
  if(isImage(path)){
    myImage = loadImage(path);
    myImage.loadPixels();
    imagePos = new PVector((width - myImage.width)/2, (height - myImage.height)/2);
    imageLoaded = true;
    showImage = false;
    
    //Only call new accordion if we havent created it yet
    if(cp5.getController("cellWidth") == null){
      setParametersGroup();
    }
    
  }else{
    imageLoaded = false;
    showImage = false;
    msg = "The selected file is not an image. \n Please try again.";
    tip = "Any jpg, png, gif, or tif file should work.";
  }
}

public boolean isImage(String path){
  path = path.toLowerCase();
  if (path.endsWith("jpg") || path.endsWith("jpeg") || path.endsWith("gif") || path.endsWith("png")){
    return true;
  }else{
    return false;
  }  
}

public void setParametersGroup(){  
  
  Group g1 = cp5.addGroup("parameters")
                .setWidth(cWidth + 2 * cPadding)
                .setBackgroundHeight(4 * cHeight + 7 * cPadding)
                .setBackgroundColor(bgColor)  
                .setColorBackground(btColorBackground)
                .setColorForeground(btColorForeground)
                .setColorActive(btColorActive)                     
                ;

  cp5.addSlider("cellWidth")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)       
     .setRange(10.5f, 84)
     .setCaptionLabel("Braille Cell Size")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.LEFT, ControlP5.BOTTOM_OUTSIDE)     
     ;
     
  cY += cHeight + 2 * cPadding;

  cp5.addToggle("fixedSize")
     .setPosition(cX, cY)
     .setSize(cWidth/4, cHeight)
     .setColorBackground(btColorForeground)
     .setColorActive(color(0, 50))   
     .setCaptionLabel("Fixed Size")
     .setMode(ControlP5.SWITCH)
     .setGroup(g1)
     ;  

  cX += cWidth/4 + 2 * cPadding;

  cp5.addToggle("showImage")
     .setPosition(cX, cY)
     .setSize(cWidth/4, cHeight)
     .setColorBackground(btColorForeground)
     .setColorActive(color(0, 50))  
     .setCaptionLabel("Show Image")
     .setMode(ControlP5.SWITCH)
     .setGroup(g1)
     ;  

  cX = cPadding;
  cY += cHeight + 2 * cPadding;
     
  cp5.addButton("savePDF")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)          
     .setCaptionLabel("Save PDF")
     .setGroup(g1)     
     .getCaptionLabel()
     .align(ControlP5.CENTER, ControlP5.CENTER)     
     ;   
     
  cX = cPadding;
  cY += cHeight + cPadding;

  cp5.addButton("savePNG")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)     
     .setCaptionLabel("Save PNG")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.CENTER, ControlP5.CENTER)     
     ;       

  accordion.addItem(g1)
           .open(1)
           ;
}

public void savePDF(){  
  selectFolder("Select a destination folder:", "folderSelectedPDF");
}

public void folderSelectedPDF(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    destinationFolderPDF = selection.getAbsolutePath();
    println("User selected " + destinationFolderPDF);
    msg = "PDF succesfully saved."; 
    tip = "Click anywhere to continue editing.";   
  }
}

public void savePNG(){  
  selectFolder("Select a destination folder:", "folderSelectedPNG");
}

public void folderSelectedPNG(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    destinationFolderPNG = selection.getAbsolutePath();
    println("User selected " + destinationFolderPNG);
    msg = "Image succesfully saved.";
    tip = "Click anywhere to continue editing.";
  }
}
class roundButton{

  PVector pos;
  int diameter;
  
  roundButton(){
    diameter = 30;
    pos = new PVector(width - 20 - diameter/2, 20 + diameter/2);
  }
  
  public void display(){
    // Color/Interaction
    int currColor = btColorBackground;
    if(isHovering()){
      currColor = btColorForeground;    
    }
    
    // Ellipse
    noStroke();
    fill(currColor);
    strokeWeight(2);
    ellipse(pos.x, pos.y, diameter, diameter);
    
    // Text
    fill(0, 160);
    textFont(myFont);
    textSize(19);
    textAlign(CENTER, CENTER);
    text("?", pos.x, pos.y - 1);    
  }
  
  public boolean isHovering(){
    if(dist(mouseX, mouseY, pos.x, pos.y) < diameter/2){
      cursor(HAND);
      return true;
    }else{
      cursor(ARROW);
      return false;
    }
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "filter_braille" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
