import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.pdf.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class filter_unknown_pleasures extends PApplet {

    // PDF

java.io.File selectedFile;  // File system
String destinationFolderPDF;
boolean isRecordingPDF = false;
String destinationFolderPNG;
boolean isSavingPNG = false;

// Image
PImage myImage;
PVector imagePos;
boolean imageLoaded = false;
boolean showImage = false;

// Message
String msg;
String tip;
PFont myFont;

// About
roundButton btAbout;

// Buttons
int bgColor;
int btColorBackground;
int btColorForeground;
int btColorActive;

// Icon
PGraphics icon;

// Noise
float noiseScale = 0.02f;
float ySpacing = 20;
float minNoiseHeight = 10;
float maxNoiseHeight = 30;

public void setup(){
  
  

  // Creating Windows Icon
  icon = createGraphics(16, 16, JAVA2D);
  PImage imageIcon = loadImage("icon_16x16.gif");
  icon.beginDraw();
  icon.background(255);
  icon.image(imageIcon, 0, 0);
  icon.endDraw();
  frame.setIconImage(icon.image);
  frame.setTitle("Filter: Unknown Pleasures"); 

  // Message
  myFont = createFont("Helvetica", 21);
  msg = "Please select an image to start.";
  tip = "Tip: High contrast, black and white images work better. \n Up to 800 x 800 pixels, jpg, png, or gif.";
  
  // About
  btAbout = new roundButton();  

  // GUI
  setGUI();
}

public void draw(){
  
  if(destinationFolderPDF != null) {
    println("Recording PDF");
    isRecordingPDF = true;
    String fileName = destinationFolderPDF + "/unknown_pleasures.pdf";
    println(fileName); 
    beginRecord(PDF, fileName); 
  }else if(destinationFolderPNG != null){
    println("Saving PNG");
    isSavingPNG = true;
  }
    
  background(0);  
  
  // Start Application
  if(imageLoaded){
    
    pushMatrix();
      translate(imagePos.x, imagePos.y);
      
      // Toggle Image Visibility
      if(showImage){
        image(myImage, 0, 0);  
      }
    
      // Draw Lines
      for (int y = 0; y < myImage.height; y+= ySpacing) {
        beginShape();
          for (int x = 0; x < myImage.width; x++) {
              
              float noiseVal = noise( x * noiseScale, y* noiseScale);
//                                     (mouseY+y) * noiseScale);
              
              float noiseHeight = map(brightness(getColorAt(x, y)),
                                      0, 255,
                                      maxNoiseHeight, minNoiseHeight);
                                      
              vertex(x, y - noiseVal * noiseHeight);
          }
          fill(0);
          stroke(255);
          strokeWeight(1);
        endShape();
      }
    popMatrix();
    
  // Message  
  }else{
    fill(color(255, 48, 97, 60));
    noStroke();
    rect(0, 0, width, height);
    fill(255);
    textFont(myFont);
    textSize(21);
    textAlign(CENTER, BOTTOM);
    text(msg, width/2, height/2);
    textSize(13);
    textLeading(21);
    textAlign(CENTER, TOP);
    text(tip, width/2, height/2 + 10);    
  }
  
  if(isRecordingPDF){
    endRecord();
    destinationFolderPDF = null;
    isRecordingPDF = false;
    imageLoaded = false;
    println("Finished recording.");
  }
  
  if(isSavingPNG){
    save(destinationFolderPNG + "/unknown_pleasures.png");
    destinationFolderPNG = null;
    isSavingPNG = false;
    imageLoaded = false;
    println("Finished saving.");
  }
  
  btAbout.display();
}

public int getColorAt(int _x, int _y){
  int i = _y * myImage.width + _x;
  int c = myImage.pixels[i];
  return c;  
}

public void mouseReleased(){
  if(imageLoaded == false && myImage != null){
    imageLoaded = true;
  }
  if(btAbout.isHovering()){
    link("http://gianordoli.com/projects.html#nAOAh0kazd");
  }  
}
//GUI

ControlP5 cp5;
Accordion accordion;

int cWidth = 150;
int cHeight = 20;
int cPadding = 10;
int cX = cPadding;
int cY = cPadding;

public void setGUI(){
  
  cp5 = new ControlP5(this);
  
  bgColor = color(255, 48, 97, 100);
  btColorBackground = color(255, 48, 97, 160);
  btColorForeground = color(255, 48, 97, 230);
  btColorActive = color(255, 48, 97, 255);
  
  //Toggle visibility 
  cp5.mapKeyFor(new ControlKey() {
    public void keyEvent() {
      if(accordion.isVisible()){
        accordion.setVisible(false);  
      }else{
        accordion.setVisible(true);
      }
    }
  }, '0');
  
  accordion = cp5.addAccordion("acc")
                 .setPosition(10, 10)
                 .setWidth(cWidth + 2* cPadding)                
                 ;                 
                 
  setAddFileGroup();
}

public void setAddFileGroup(){
  Group g0 = cp5.addGroup("input")
                .setWidth(cWidth + 2 * cPadding)
                .setBackgroundColor(bgColor)
                .setColorBackground(btColorBackground)
                .setColorForeground(btColorForeground)
                .setColorActive(btColorActive)                 
                ;

  cp5.addButton("select")  
     .setPosition(cX, cY)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)
     .setCaptionLabel("Select Image")
     .setGroup(g0)   
     ;
   
  accordion.addItem(g0)
           .setItemHeight(cHeight + 2 * cPadding)
           ;
           
  accordion.open(0)
           .setCollapseMode(Accordion.MULTI)
           ;           
}

public void select() {  
  selectInput("Select an image file:", "fileSelected");
}

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    String path = selection.getAbsolutePath();
    println("User selected " + path);
    createImage(path);
  }
}

public void createImage(String path){
  if(isImage(path)){
    myImage = loadImage(path);
    myImage.loadPixels();
    imagePos = new PVector((width - myImage.width)/2, (height - myImage.height)/2);
    imageLoaded = true;
    showImage = false;
    
    //Only call new accordion if we havent created it yet
    if(cp5.getController("minNoiseHeight") == null){
      setParametersGroup();
    }
    
  }else{
    imageLoaded = false;
    showImage = false;
    msg = "The selected file is not an image. \n Please try again.";
    tip = "Any jpg, png, gif, or tif file should work.";
  }
}

public boolean isImage(String path){
  path = path.toLowerCase();
  if (path.endsWith("jpg") || path.endsWith("jpeg") || path.endsWith("gif") || path.endsWith("png")){
    return true;
  }else{
    return false;
  }  
}

public void setParametersGroup(){

  Group g1 = cp5.addGroup("parameters")
                .setWidth(cWidth + 2 * cPadding)
                .setBackgroundHeight(6 * cHeight + 11 * cPadding)
                .setBackgroundColor(bgColor)  
                .setColorBackground(btColorBackground)
                .setColorForeground(btColorForeground)
                .setColorActive(btColorActive)                 
                ;

  cp5.addSlider("minNoiseHeight")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)     
     .setRange(0, 20)
     .setCaptionLabel("Minimum Line Height")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.LEFT, ControlP5.BOTTOM_OUTSIDE)     
     ;
     
  cY += cHeight + 2 * cPadding;

  cp5.addSlider("maxNoiseHeight")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)     
     .setRange(10, 100)
     .setCaptionLabel("Maximum Line Height")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.LEFT, ControlP5.BOTTOM_OUTSIDE)     
     ;
     
  cY += cHeight + 2 * cPadding;

  cp5.addSlider("ySpacing")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)     
     .setRange(5, 50)
     .setCaptionLabel("Y Spacing")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.LEFT, ControlP5.BOTTOM_OUTSIDE)     
     ;
     
  cY += cHeight + 2 * cPadding;
  
  cp5.addToggle("showImage")
     .setPosition(cX, cY)
     .setSize(cWidth/4, cHeight)
     .setColorBackground(btColorForeground)
     .setColorActive(color(0, 50)) 
     .setCaptionLabel("Show Image")
     .setMode(ControlP5.SWITCH)
     .setGroup(g1)
     ;
     
  cX = cPadding;
  cY += cHeight + 2 * cPadding;
     
  cp5.addButton("savePDF")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)     
     .setCaptionLabel("Save PDF")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.CENTER, ControlP5.CENTER)     
     ;        

  cX = cPadding;
  cY += cHeight + cPadding;

  cp5.addButton("savePNG")
     .setPosition(cX, cY)
     .setSize(cWidth, cHeight)
     .setColorBackground(btColorBackground)
     .setColorForeground(btColorForeground)
     .setColorActive(btColorActive)     
     .setCaptionLabel("Save PNG")
     .setGroup(g1)
     .getCaptionLabel()
     .align(ControlP5.CENTER, ControlP5.CENTER)     
     ;        


  accordion.addItem(g1)
           .open(1)
           ;
  
//  println(cp5.getProperties());
}

public void savePDF(){  
  selectFolder("Select a destination folder:", "folderSelectedPDF");
}

public void folderSelectedPDF(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    destinationFolderPDF = selection.getAbsolutePath();
    println("User selected " + destinationFolderPDF);
    msg = "PDF succesfully saved."; 
    tip = "Click anywhere to continue editing.";   
  }
}

public void savePNG(){  
  selectFolder("Select a destination folder:", "folderSelectedPNG");
}

public void folderSelectedPNG(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    destinationFolderPNG = selection.getAbsolutePath();
    println("User selected " + destinationFolderPNG);
    msg = "Image succesfully saved.";
    tip = "Click anywhere to continue editing.";
  }
}
class roundButton{

  PVector pos;
  int diameter;
  
  roundButton(){
    diameter = 30;
    pos = new PVector(width - 20 - diameter/2, 20 + diameter/2);
  }
  
  public void display(){
    
    // Color/Interaction
    int currColor = btColorBackground;
    if(isHovering()){
      currColor = btColorForeground;    
    }
    
    // Ellipse
    noStroke();
    fill(currColor);
    strokeWeight(2);
    ellipse(pos.x, pos.y, diameter, diameter);
    
    // Text
    fill(0, 160);
    textFont(myFont);
    textSize(19);
    textAlign(CENTER, CENTER);
    text("?", pos.x, pos.y - 1);    
  }
  
  public boolean isHovering(){
    if(dist(mouseX, mouseY, pos.x, pos.y) < diameter/2){
      cursor(HAND);
      return true;
    }else{
      cursor(ARROW);
      return false;
    }
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "filter_unknown_pleasures" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
